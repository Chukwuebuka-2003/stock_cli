"""Stock Tracker CLI package."""
